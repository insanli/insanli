#!/usr/bin/env python3
"""Build www.insanlik.tr: the start page, the Reports (Raporlar) section and the Projects pages.

Reads content/ and templates/, writes the finished site to _site/.
GitHub runs this automatically after every change (.github/workflows/deploy.yml).
Local test:  pip install -r requirements.txt && python build.py
"""
import glob
import os
import re
import shutil
import zipfile
import sys

import yaml
from jinja2 import Environment, FileSystemLoader

ROOT = os.path.dirname(os.path.abspath(__file__))
CONTENT = os.path.join(ROOT, 'content')
OUT = os.path.join(ROOT, '_site')
MONTHS = {
    'en': ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    'tr': ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'],
    'ar': ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
}
errors = []


def read(path):
    try:
        with open(path, encoding='utf-8') as f:
            return yaml.safe_load(f) or {}
    except yaml.YAMLError as e:
        errors.append(f'{os.path.relpath(path, ROOT)}: could not be read ({e}). Check colons, quotes and indentation.')
        return {}


def fmt_period(value, lang):
    m = re.match(r'(\d{4})-(\d{1,2})', str(value or ''))
    return f'{MONTHS[lang][int(m.group(2)) - 1]} {m.group(1)}' if m else str(value or '')


def fmt_date(value, lang):
    m = re.match(r'(\d{4})-(\d{1,2})-(\d{1,2})', str(value or ''))
    return f'{int(m.group(3))} {MONTHS[lang][int(m.group(2)) - 1]} {m.group(1)}' if m else str(value or '')


def localize_prices(html, lang):
    """$4.50 -> $4,50 ; $2,250 -> $2.250 ; $9870.00 -> $9.870,00 (English digits in every language)."""
    def one(m):
        raw = m.group(2).replace(',', '')
        whole, _, dec = raw.partition('.')
        out = f'{int(whole):,}'.replace(',', '.') + (',' + dec if dec else '')
        return (m.group(1) or '') + out
    return re.sub(r'(\$)?(\d[\d,]*(?:\.\d+)?)(?(1)|(?=\s?\$))', one, html)


# Gaza "Food Security" table: (price now on the site, new price), in the order they appear on the page:
# unit cost, then "funding from" for GAZ-I001, I002, I003, I004, I005, I006, I007, I071, I072, I073, I074
GAZA_FOOD = [
    (4.5, '5.50'), (2250, '2,750'),
    (220, '245.00'), (1320, '1,470'),
    (165, '165.00'), (990, '990'),
    (20, '30.00'), (4000, '6,000'),
    (2.2, '2.20'), (2200, '2,200'),
    (33, '47.00'), (3300, '4,700'),
    (50, '60.00'), (5000, '6,000'),
    (9870, '10,164.00'), (9870, '10,164'),
    (39600, '43,560.00'), (39600, '43,560'),
    (7770, '6,930.00'), (7770, '6,930'),
    (30600, '29,700.00'), (30600, '29,700'),
]

# Sentence shown under the title of the Gaza quick-funding page (replaces the old sentence)
HERO_TEXT = {
    'tr': 'Gıda Güvenliği • Su, Sanitasyon ve Hijyen • Sağlık • Barınma ve Temel İhtiyaç Malzemeleri • Eğitim ve Toplum Hizmetleri',
    'en': 'Food Security • Water, Sanitation and Hygiene • Health • Shelter and Basic Needs Supplies • Education and Community Services',
    'ar': 'الأمن الغذائي • المياه والصرف الصحي والنظافة • الصحة • المأوى والمستلزمات الأساسية • التعليم والخدمات المجتمعية',
}


def replace_hero_text(html, lang):
    """Replace the intro sentence under the page title (the first <p> right after the first </h1>)."""
    return re.subn(r'(</h1>(?:(?!<h[12][\s>]|<p[\s>]|</section).)*?<p(?:\s[^>]*)?>)[^<]{10,400}(</p>)',
                   lambda m: m.group(1) + HERO_TEXT[lang] + m.group(2), html, count=1, flags=re.S)


def override_prices(html, pairs):
    """Go through the $ amounts in page order. When an amount equals the next expected old price, write the new one."""
    state = [0]

    def one(m):
        if state[0] >= len(pairs):
            return m.group(0)
        s = m.group(1)
        v = float(s.replace('.', '') if re.fullmatch(r'\d{1,3}(?:\.\d{3})+', s) else s.replace(',', ''))
        old, new = pairs[state[0]]
        if abs(v - old) < 0.001:
            state[0] += 1
            return '$' + new
        return m.group(0)
    out = re.sub(r'\$(\d[\d,.]*\d|\d)', one, html)
    return out, state[0]


# Project cards (Projects list, country pages, "related projects"): the short description is shown
# only on the project's own page; the cards show its Target Beneficiaries and Duration instead,
# copied from the figures strip at the top of that page (so they are always the same, in every language).
FACT_LABELS = {
    'beneficiaries': ('Target Beneficiaries', 'Hedef Faydalanıcı', 'المستفيدون المستهدفون'),
    'duration': ('Duration', 'Süre', 'مدة التنفيذ'),
}
FACT_ICONS = {
    'beneficiaries': '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    'duration': '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
}
# small grey line under a number that only repeats the label ("3000 · target beneficiaries") is left off the card
FACT_PLAIN_NOTES = ('target beneficiaries', 'hedef faydalanıcı', 'مستفيداً مستهدفاً')
# not filled in yet on the project page: the card shows nothing for it until it is
FACT_PLACEHOLDERS = ('TO BE ADDED', 'EKLENECEK', 'سيُضاف')


def project_facts(lang):
    """{project code: [(kind, label, value, note), ...]} read from each project page of one language."""
    facts = {}
    for f in glob.glob(os.path.join(OUT, lang, 'projects', '*', 'index.html')):
        code = os.path.basename(os.path.dirname(f))
        m = re.search(r'<section class="stats-strip">(.*?)</section>', open(f, encoding='utf-8').read(), re.S)
        if not m:
            continue
        found = {}
        for st in re.findall(r'<div class="st">(.*?)</div>', m.group(1), re.S):
            label = re.search(r'<span class="small-label">(.*?)</span>', st, re.S)
            value = re.search(r'<strong>(.*?)</strong>', st, re.S)
            note = re.search(r'<span class="st-note">(.*?)</span>', st, re.S)
            if not (label and value):
                continue
            label, value, note = label.group(1).strip(), value.group(1).strip(), (note.group(1).strip() if note else '')
            kind = next((k for k, names in FACT_LABELS.items() if label in names), None)
            if not kind or not value or value in FACT_PLACEHOLDERS:
                continue
            if not value[:1].isdigit() or note.lower() in FACT_PLAIN_NOTES:
                note = ''
            found[kind] = (kind, label, value, note)
        facts[code] = [found[k] for k in FACT_LABELS if k in found]
    return facts


def facts_html(rows):
    out = []
    for kind, label, value, note in rows:
        icon = ('<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" '
                'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + FACT_ICONS[kind] + '</svg>')
        val = f'<strong>{value}</strong>' + (f' <span class="pcard-fact-note">{note}</span>' if note else '')
        out.append(f'<div class="pcard-fact pcard-fact-{kind}">{icon}<div><span class="small-label">{label}</span>'
                   f'<span class="pcard-fact-val">{val}</span></div></div>')
    return '<div class="pcard-facts">' + ''.join(out) + '</div>' if out else ''


def cards_with_facts(html, lang, facts):
    """Every project card on the page: description out, beneficiaries + duration in. Returns (html, cards changed)."""
    n = [0]

    def card(m):
        rows = facts.get(m.group(2))
        if rows is None:
            print(f'  note: no project page found for card {m.group(2)} ({lang})')
        body, k = re.subn(r'<p class="pcard-text">.*?</p>', lambda _: facts_html(rows or []), m.group(3), count=1, flags=re.S)
        n[0] += k
        return m.group(1) + body + '</a>'
    out = re.sub(r'(<a class="pcard"[^>]*\bhref="/%s/projects/([^/"]+)/"[^>]*>)(.*?)</a>' % lang, card, html, flags=re.S)
    return out, n[0]


def main():
    S = read(os.path.join(CONTENT, 'settings.yml'))
    langs = S.get('languages', ['tr', 'en', 'ar'])
    cats = S.get('categories', ['country', 'sectoral', 'needs', 'emergency', 'data'])
    T = {l: read(os.path.join(CONTENT, 'text', f'{l}.yml')) for l in langs}
    impact = read(os.path.join(CONTENT, 'data', 'impact.yml'))
    reports = []
    for p in sorted(glob.glob(os.path.join(CONTENT, 'reports', '*.yml'))):
        name = os.path.basename(p)[:-4]
        if name.startswith('_'):
            continue
        r = read(p)
        rel = os.path.relpath(p, ROOT)
        if not r or r.get('draft'):
            continue
        if r.get('category') not in cats or r.get('category') == 'data':
            errors.append(f'{rel}: "category:" must be one of: country, sectoral, needs, emergency')
            continue
        for l in langs:
            if not (r.get(l) or {}).get('title'):
                errors.append(f'{rel}: the "{l}" part has no title.')
        if r.get('image') and not os.path.exists(os.path.join(ROOT, 'static', r['image'].lstrip('/'))):
            errors.append(f'{rel}: image "{r["image"]}" not found. Upload it to static{r["image"]}')
        r['slug'] = name
        reports.append(r)
    if errors:
        report()
    reports.sort(key=lambda r: (str(r.get('updated') or r.get('period') or ''), -(r.get('order') or 0)), reverse=True)

    env = Environment(loader=FileSystemLoader(os.path.join(ROOT, 'templates')), autoescape=True, trim_blocks=True, lstrip_blocks=True)
    env.globals['S'] = S
    env.globals['cats'] = cats
    env.filters['period'] = fmt_period
    env.filters['date'] = fmt_date
    env.filters['loc'] = lambda v, lang='en': str(v).replace(',', '.') if lang == 'tr' and str(v).replace(',', '').isdigit() else v
    env.filters['num'] = lambda n, lang='en': f'{n:,}'.replace(',', '.' if lang == 'tr' else ',')

    if os.path.exists(OUT):
        shutil.rmtree(OUT)
    shutil.copytree(os.path.join(ROOT, 'static'), OUT)
    # project pages (built earlier from the Zoho portfolio): copied, with the Projects top bar put in
    has_projects = True
    if os.path.isdir(os.path.join(ROOT, 'portfolio')):
        shutil.copytree(os.path.join(ROOT, 'portfolio'), OUT, dirs_exist_ok=True)
    elif os.path.exists(os.path.join(ROOT, 'portfolio.zip')):
        with zipfile.ZipFile(os.path.join(ROOT, 'portfolio.zip')) as z:
            z.extractall(OUT)
    else:
        has_projects = False
    if has_projects:
        hdr_tpl = env.get_template('proj_header.html')
        WC = read(os.path.join(CONTENT, 'women-children.yml'))
        for l in langs:
            facts = project_facts(l)
            cards_done = 0
            areas = []
            ai = os.path.join(OUT, l, 'areas', 'index.html')
            if os.path.exists(ai):
                areas = [dict(url=u.replace('/areas//', '/areas/africa/'), title=n.strip()) for u, n in re.findall(
                    r'<a class="tile[^"]*" href="(/%s/areas/[^"]*)"[^>]*>(?:(?!</a>).)*?<span class="tile-name">([^<]+)</span>' % l,
                    open(ai, encoding='utf-8').read(), re.S)]
            for f in glob.glob(os.path.join(OUT, l, '**', '*.html'), recursive=True):
                html = open(f, encoding='utf-8').read()
                m = re.search(r'<header class="hdr" id="top">.*?</header>', html, re.S)
                if not m:
                    continue
                alt = {lg: href for href, lg in re.findall(r'<a href="([^"]+)" hreflang="(\w\w)"', m.group(0))}
                alt = {lg: alt.get(lg, f'/{lg}/projects/') for lg in langs}
                section = os.path.relpath(f, os.path.join(OUT, l)).split(os.sep)[0]
                section = {'kits': 'quick-funding', 'about': '', 'achievements': ''}.get(section, section)
                new = hdr_tpl.render(lang=l, t=T[l], T=T, langs=langs, alt=alt, section=section, areas=areas)
                html = html[:m.start()] + new + html[m.end():]
                html = html.replace('/img/brand/logo-ar.png', '/img/brand/logo-en.png')
                html = html.replace(f'href="/{l}/areas//"', f'href="/{l}/areas/africa/"')  # Africa tile link
                # same photo banner as the Reports pages
                html = html.replace('<section class="phero "', f'<section class="phero has-img" style="--bg:url(\'{S.get("projects_image", "")}\')"')
                if WC.get('wash_label', {}).get(l):
                    html = html.replace('>WASH<', '>' + WC['wash_label'][l] + '<')
                if section == 'projects' and f.endswith(os.path.join('projects', 'index.html')):
                    label = (WC.get('label') or {}).get(l, 'Women & Children')
                    html = re.sub(r'(<select data-filter="sector">.*?)(</select>)', lambda mm: mm.group(1) + f'<option value="women-children">{label}</option>' + mm.group(2), html, count=1, flags=re.S)
                    for code in WC.get('projects', []):
                        html = html.replace(f'<a class="pcard" href="/{l}/projects/{code}/"', f'<a class="pcard" data-groups="women-children" href="/{l}/projects/{code}/"')
                html, k = cards_with_facts(html, l, facts)
                cards_done += k
                with open(f, 'w', encoding='utf-8') as fh:
                    fh.write(html)
            print(f'CARDS {l}: {cards_done} project cards now show beneficiaries + duration ({len(facts)} project pages read)')

    pages, refs = [], {}
    for l in langs:
        t = T[l]
        R = []
        for r in reports:
            x = {k: v for k, v in r.items() if k not in langs}
            x.update(r.get(l) or r.get('en') or {})
            x['url'] = f'/{l}/reports/{r["category"]}/{r["slug"]}/'
            R.append(x)
        imp = dict(impact.get(l) or {})
        base = dict(lang=l, t=t, dir='rtl' if l == 'ar' else 'ltr', langs=langs, T=T, reports=R,
                    contact=(S.get('contacts') or {}).get(l, {}))

        def add(tpl, url, ref, **kw):
            pages.append((tpl, url, ref, dict(base, **kw)))
            refs.setdefault(ref, {})[l] = url

        add('landing.html', f'/{l}/', 'home')
        add('reports_home.html', f'/{l}/reports/', 'reports')
        for c in cats:
            if c == 'data':
                add('data.html', f'/{l}/reports/data/', 'reports/data', imp=imp,
                    country_reports=[r for r in R if r['category'] == 'country'])
            elif c == 'needs':
                add('needs.html', f'/{l}/reports/needs/', 'reports/needs', items=[r for r in R if r['category'] == 'needs'],
                    country_reports=[r for r in R if r['category'] == 'country'])
            else:
                add('report_list.html', f'/{l}/reports/{c}/', f'reports/{c}', cat=c, items=[r for r in R if r['category'] == c])
        for r in R:
            add('report.html', r['url'], 'reports/' + r['slug'], r=r,
                more=[x for x in R if x['category'] == r['category'] and x['slug'] != r['slug']][:3])

    for tpl, url, ref, ctx in pages:
        alt = {ll: refs.get(ref, {}).get(ll) or f'/{ll}/' for ll in langs}
        write(url, env.get_template(tpl).render(**ctx, alt=alt, ref=ref, page_url=url))
    write('/', env.get_template('root.html').render(langs=langs, default=S.get('default_lang', 'tr'), T=T))
    base_url = S.get('url', '').rstrip('/')
    urls = [p[1] for p in pages] + sorted('/' + os.path.relpath(os.path.dirname(f), OUT).replace(os.sep, '/') + '/'
                                          for f in glob.glob(os.path.join(OUT, '*', '**', 'index.html'), recursive=True)
                                          if '/reports/' not in f and os.path.dirname(os.path.dirname(f)) != OUT)
    sm = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    sm += [f'  <url><loc>{base_url}{u}</loc></url>' for u in dict.fromkeys(urls)]
    write('/sitemap.xml', '\n'.join(sm + ['</urlset>']) + '\n')
    write('/robots.txt', f'User-agent: *\nAllow: /\nSitemap: {base_url}/sitemap.xml\n')
    # cache-busting: browsers fetch the new CSS/JS/logos after every change
    import hashlib
    ver = {u: hashlib.md5(open(os.path.join(OUT, u.lstrip('/')), 'rb').read()).hexdigest()[:8]
           for u in ['/css/style.css', '/js/main.js'] + ['/img/brand/' + n for n in os.listdir(os.path.join(OUT, 'img', 'brand')) if n.endswith('.png')]}
    # prices: thousands written with dots ($10.000 instead of $10,000)
    price = re.compile(r'(?:\$|USD\s?)\d{1,3}(?:,\d{3})+|\d{1,3}(?:,\d{3})+(?=\s?(?:\$|USD))')
    for f in glob.glob(os.path.join(OUT, '**', '*.html'), recursive=True):
        html = open(f, encoding='utf-8').read()
        rel = os.path.relpath(f, OUT).replace(os.sep, '/')
        mm = re.match(r'(tr|en|ar)/(quick-funding/gaza/|kits/gaz-)', rel)
        if mm:
            if mm.group(2) == 'quick-funding/gaza/':
                html, n = override_prices(html, GAZA_FOOD)
                print(f'PRICES {rel}: {n} of {len(GAZA_FOOD)} updated')
                html, k = replace_hero_text(html, mm.group(1))
                print(f'HERO {rel}: ' + ('replaced' if k else 'NOT FOUND'))
            html = localize_prices(html, mm.group(1))
        html = price.sub(lambda mm: mm.group(0).replace(',', '.'), html)
        new = re.sub(r'(["\'(])(' + '|'.join(re.escape(u) for u in ver) + r')(?=["\')])', lambda mm: mm.group(1) + mm.group(2) + '?v=' + ver[mm.group(2)], html)
        with open(f, 'w', encoding='utf-8') as fh:
            fh.write(new)
    print(f'Built {len(pages)} report pages (+ project pages) into _site/')


def write(url, content):
    path = url.lstrip('/')
    if path == '' or path.endswith('/'):
        path += 'index.html'
    full = os.path.join(OUT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, 'w', encoding='utf-8') as f:
        f.write(content)


def report():
    print('\nThe site was NOT updated because of these problems:\n', file=sys.stderr)
    for e in errors:
        print('  - ' + e, file=sys.stderr)
    sys.exit(1)


if __name__ == '__main__':
    main()
